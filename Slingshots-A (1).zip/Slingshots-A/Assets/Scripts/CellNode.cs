﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CellNode : MonoBehaviour
{
    private int g;
    private int h;
    private int f;
    private CellNode parent;


    void Start() {
        parent = null;    
    }


    public void SetG(int g) {
		this.g = g;
	}

    public void SetH(int h) {
		this.h = h;
	}

	public void SetF(int f) {
		this.f = f;
	}

    public void SetParent(CellNode parent) {
		this.parent = parent;
	}

    public int GetGCost() {return g;}

	public int GetHCost() {return h;}

	public int GetFCost() {return f;}
    public CellNode GetParent(){return parent;}
    public void UpdateUI(){
        GetComponent<Cell>().UpdateUI();
    }

    public void SetData(CellNode ce){
        g = ce.GetGCost();
        h = ce.GetHCost();
        f = ce.GetFCost();
    }
}
