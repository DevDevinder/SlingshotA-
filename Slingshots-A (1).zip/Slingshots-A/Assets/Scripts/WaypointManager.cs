﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaypointManager : MonoBehaviour
{
    public static WaypointManager instance;     //Instance to access this object

    public int width_waypoint_num = 50;
    private int height_waypoint_num = 56;

    public Transform waypoints_holder;          //Parent of waypoints

    private const string WAYPOINT_PATH = "Prefabs/Waypoint";
    private List<GameObject> waypoints = new List<GameObject>();


    void Awake() {
        if(instance == null)instance = this;    //setting up the instance to this object
    }

    void Start() {
        CalculateWaypointAmount();
        SpawnWaypoints();
    }

    private void CalculateWaypointAmount(){ //Scale everything based on width_waypoint_num considering: 1920-1080 monitor
        if(width_waypoint_num % 100 != 0){
            height_waypoint_num = 56 * width_waypoint_num / 100;
        }else{
            if(height_waypoint_num % 56 != 0){
                height_waypoint_num = 56 * (width_waypoint_num / 100);
            }
        }
    }

    public void SpawnWaypoints(){
        float waypoint_size = Screen.width / width_waypoint_num;    //Calculate the waypoint size based on the screen size and waypoint num
        Vector2 first_pos = new Vector2((waypoint_size / 2) - (Screen.width / 2), (waypoint_size / 2) - (Screen.height / 2));
        int id = 1;

        for(int x = 0; x < width_waypoint_num; x++){
            for(int y = 0; y < height_waypoint_num; y++){
                Vector2 pos = new Vector2(first_pos.x + waypoint_size * x,first_pos.y + waypoint_size * y);
                GameObject go = Instantiate<GameObject>(Resources.Load<GameObject>(WAYPOINT_PATH));

                go.transform.parent = waypoints_holder;
                go.GetComponent<BoxCollider2D>().size = new Vector2(waypoint_size, waypoint_size);
                go.transform.localPosition = pos;
                go.GetComponent<Waypoint>().SetID(id);
                id++;

                waypoints.Add(go);
            }
        }
    }
}
