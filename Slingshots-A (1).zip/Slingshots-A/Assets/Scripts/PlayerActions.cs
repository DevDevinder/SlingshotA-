﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerActions : MonoBehaviour
{
    public float force = 10f;

    
    private Vector2 startPos;
    private bool isClicking = false;
    private const string PAINTERBALL_PATH = "Prefabs/PaintedBall";
    private GameObject painted_ball;

    void Update() {
        if(Input.GetMouseButtonDown(0) && !isClicking){ //Get first click position
            startPos = Input.mousePosition;
            isClicking = true;
            SpawnPaintedBall();
        }

        if(Input.GetMouseButtonUp(0)){  //Get last click position
            Vector2 distance = new Vector2(startPos.x - Input.mousePosition.x, startPos.y - Input.mousePosition.y);
            
            painted_ball.GetComponent<Rigidbody2D>().AddForce(distance * force);
        }
    }

    private void SpawnPaintedBall(){
        GameObject go = Instantiate<GameObject>(Resources.Load<GameObject>(PAINTERBALL_PATH), transform.position, Quaternion.identity);
        go.transform.parent = transform;
        painted_ball = go;
    }

}
