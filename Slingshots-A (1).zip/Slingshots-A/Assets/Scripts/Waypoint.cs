﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Waypoint : MonoBehaviour
{
    private int id;

    public void SetID(int _id){id = _id;}
    public int GetID(){return id;}

    
}
