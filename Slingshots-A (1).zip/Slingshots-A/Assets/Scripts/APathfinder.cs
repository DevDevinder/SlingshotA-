﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class APathfinder : MonoBehaviour
{
    private float map_min_x;
    private float map_min_y;
    private float map_max_x;
    private float map_max_y;

    private GameObject start_cell;
    private GameObject end_cell;
    private GameObject closest_cell;
    private int cell_size;

    private int standard_move = 10;
    private int standard_diagonal = 14;

    private GameObject near_cell;

    private List<GameObject> final_path = new List<GameObject>();
    private List<GameObject> every_cell = new List<GameObject>();
    private List<int> cell_id_found = new List<int>();

    public void SetPathfinderVariables(){   //Set up all the variable from the MapHandler. DO NOT TOUCH pls <3
        Vector2 container_size = GetComponent<MapHandler>().cell_container.GetComponent<RectTransform>().rect.size;
        cell_size = GetComponent<MapHandler>().cell_size;

        map_min_x = -container_size.x / 2 + cell_size / 2;
        map_max_y = container_size.y / 2 - cell_size / 2;
        map_max_x = container_size.x / 2 - cell_size / 2;
        map_min_y = -container_size.y / 2 + cell_size / 2;

        start_cell = GetComponent<MapHandler>().start_cell;
        end_cell = GetComponent<MapHandler>().end_cell;
        closest_cell = start_cell;
        near_cell = null;
    }

    public void CalculateNearClosestCell(){     //Get the 8 near cells
        CellNode[] near_cells = new CellNode[8];
        for(int f = 0; f < near_cells.Length; f++){
            near_cells[f] = null;
        }

        int i = 0;
        for(int x = -1; x < 2; x++){
            for(int y = 1; y > -2; y--){
                if(x == 0 && y == 0){
                    //this cell, skip it
                }else{
                    Vector3 pos = new Vector3(closest_cell.transform.position.x + x * cell_size, closest_cell.transform.position.y + y * cell_size, 1);
                    CellNode cell = MapHandler.instance.GetCellNodeByPosition(pos);
                    if(cell != null && !cell.gameObject.GetComponent<Cell>().IsWall()){
                        near_cells[i] = cell;
                    }
                    i++;
                }
            }
        }

        //Here we have all the near cells on the array
        foreach(CellNode c in near_cells){
            if(c != null && c.gameObject != start_cell && c.gameObject != end_cell){
                float distanceX = Mathf.Abs(c.gameObject.transform.position.x - closest_cell.transform.position.x);
                float distanceY = Mathf.Abs(c.gameObject.transform.position.y - closest_cell.transform.position.y);

                //Calculate G Cost
                int gcost = 10;
                gcost = GetCost((int)distanceX, (int)distanceY);

                c.SetG(gcost);

                //Calculate H Cost
                distanceX = Mathf.Abs(c.gameObject.transform.position.x - end_cell.transform.position.x);
                distanceY = Mathf.Abs(c.gameObject.transform.position.y - end_cell.transform.position.y);

                int hcost = 0;
                hcost = GetCost((int)distanceX, (int)distanceY);
                
                c.SetH(hcost);

                c.SetF(gcost + hcost);

                c.UpdateUI();
                    
            }else if(c != null && c.gameObject == end_cell){
                near_cell = c.gameObject;
                near_cell.gameObject.GetComponent<Cell>().SetColor(Style.current_cell);
                return;
            }
        }

        int discovered = 0;
        int count = 0;
        foreach(CellNode c in near_cells){  //Find and save the near one based on the F Cost
            if(c != null ){
                if(c.gameObject != start_cell && c.gameObject != end_cell){
                    if(near_cell == null){
                        near_cell = c.gameObject;
                    }else{
                        count++;
                        if(!c.gameObject.GetComponent<Cell>().IsDiscovered()){
                            if(c.GetFCost() <= near_cell.GetComponent<CellNode>().GetFCost()){
                                near_cell.gameObject.GetComponent<Cell>().SetColor(Style.far_cell);
                                c.gameObject.GetComponent<Cell>().SetColor(Style.current_cell);
                                near_cell = c.gameObject;
                            }else{
                                discovered++;
                                c.gameObject.GetComponent<Cell>().SetColor(Style.far_cell);
                            }
                            
                            c.gameObject.GetComponent<Cell>().SetDiscover();
                        }else{
                            discovered++;
                        }
                    }

                    if(!isSaved(c.gameObject)){
                        every_cell.Add(c.gameObject);
                        cell_id_found.Add(c.GetComponent<Cell>().id);
                    }
                    
                }
            }
            
        }

        if(discovered == count){    //Search for the cheaper one
            GameObject min = every_cell[0];
            foreach(GameObject go in every_cell){
                if(go.GetComponent<Cell>().GetID() != near_cell.GetComponent<Cell>().GetID()){
                    if(go.GetComponent<CellNode>().GetFCost() < min.GetComponent<CellNode>().GetFCost()){
                        min = go;
                    }
                }
                
            }

            ClearCell(near_cell);
            near_cell.gameObject.GetComponent<Cell>().SetColor(Style.far_cell);
            min.gameObject.GetComponent<Cell>().SetColor(Style.current_cell);
            near_cell = min.gameObject;

            
        }
        Debug.Log("Addgin final");
        final_path.Add(near_cell);

    }

    private void ClearCell(GameObject cell){
        every_cell.Remove(near_cell);
        near_cell.transform.GetChild(1).gameObject.SetActive(false);
        near_cell.GetComponent<Cell>().SetColor(Style.walked_cell);
    }

    private bool isSaved(GameObject go){
        if(every_cell.Count == 0)return false;
        foreach(int g in cell_id_found){
            if(g == go.GetComponent<Cell>().GetID())return true;
        }
        return false;
    }

    private int GetCost(int distanceX, int distanceY){
        int cost = 0;

        if(distanceY == 0){ //move only on horizontal
            cost = Mathf.Abs((int)distanceX / cell_size * standard_move);
        }else if(distanceX == 0){   //move only on vertical
            cost = Mathf.Abs((int)distanceY / cell_size * standard_move);
        }else{
            //diagonal moves
            cost = Mathf.Abs((int)Mathf.Min(distanceX, distanceY) / cell_size * standard_diagonal);
            int other = (int)Mathf.Max(distanceX, distanceY) - (int)Mathf.Min(distanceX, distanceY);
            cost += Mathf.Abs(other / cell_size * standard_move);
        }

        return cost;
    }

    public void SetNewNearCell(){
        ClearCell(near_cell);
        UpdateAllOtherCells(near_cell);
        closest_cell = near_cell;
        if(closest_cell != end_cell){
            CalculateNearClosestCell();
        }else{
            //found path
            foreach(GameObject go in final_path){   //Show that with another color
                go.GetComponent<Cell>().SetColor(Style.final_path_cell);
            }
        }
        
    }

    private void UpdateAllOtherCells(GameObject near){
        foreach(GameObject go in every_cell){
            float distanceX = Mathf.Abs(go.gameObject.transform.position.x - near.transform.position.x);
            float distanceY = Mathf.Abs(go.gameObject.transform.position.y - near.transform.position.y);

            //Calculate G Cost
            int gcost = 10;
            gcost = GetCost((int)distanceX, (int)distanceY);

            go.GetComponent<CellNode>().SetG(gcost);

            go.GetComponent<CellNode>().SetF(gcost + go.GetComponent<CellNode>().GetHCost());

            go.GetComponent<CellNode>().UpdateUI();
        }
    }
    
}
