﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapHandler : MonoBehaviour
{
    public static MapHandler instance;
    public int cell_horizontal_amount = 10;
    public int cell_vertical_amount = 10;
    public int cell_size = 100;
    public GameObject cell;
    public Transform cell_container;

    List<GameObject> cells = new List<GameObject>();
    public GameObject start_cell;
    public GameObject end_cell;


    void Awake() {
        if(instance == null)instance = this;
    }

    void Start() {
        start_cell = null;
        end_cell = null;

        SpawnCells();
    }

    private void SpawnCells(){  //Spawn al the cells based on the container and cell size
        Vector2 container_size = cell_container.GetComponent<RectTransform>().rect.size;
        int id = 1;
        for(int x = 0; x < cell_horizontal_amount; x++)
        {
            for(int y = 0; y < cell_vertical_amount; y++){
                GameObject go = Instantiate<GameObject>(cell);
                go.transform.SetParent(cell_container);
                float posx = -container_size.x / 2 + cell_size / 2;
                float posy = container_size.y / 2 - cell_size / 2;
                go.transform.localPosition = new Vector3(posx + cell_size * x, posy - cell_size * y,1);
                go.transform.GetComponent<Cell>().SetID(id);
                id++;
                cells.Add(go);
            }
        }
    }

    public void SetPoint(GameObject cell, Color32 color){   //Set the start and end cell
        cell.GetComponent<Cell>().SetColor(color);
    }

    public void CellClicked(int cell_id){   //Cell clicked with the mouse.
        GameObject cell = null;
        foreach(GameObject go in cells){
            if(go.GetComponent<Cell>().GetID() == cell_id){
                cell = go;
            }
        }

        if(start_cell == null){     //If there is no startin cell, then this will be the first
            start_cell = cell;
            SetPoint(start_cell, Style.start_cell);
        }else if(end_cell == null){ //If there is no ending cell, then this will be the ending one
            end_cell = cell;
            SetPoint(end_cell, Style.end_cell);
            GetComponent<APathfinder>().SetPathfinderVariables();
        }else{  //Add or Remove wall
            foreach(GameObject go in cells){
                if(go.GetComponent<Cell>().GetID() == cell_id){
                    go.GetComponent<Cell>().SetWall(!go.GetComponent<Cell>().IsWall());
                }
            }
        }
    }

    public CellNode GetCellNodeByPosition(Vector3 pos){
        foreach(GameObject go in cells){
            if(go.transform.position == pos){
                return go.GetComponent<CellNode>();
            }
        }
        return null;
    }
}
