﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Cell : MonoBehaviour
{
    public int id;
    public int cell_add_cost = 0;   //if you can walk throw this cell but this will slow you. Ex : water cell.
                                    //this is the cost for a custom cell
    private bool isWall;
    private bool discovered;
    
    public Button colorPanel;
    private Text gCostText;
    private Text hCostText;
    private Text fCostText;

    void Start() {
        if(colorPanel == null){
            colorPanel = transform.GetComponent<Button>();
        }
        gCostText = transform.GetChild(1).GetChild(0).GetComponent<Text>();
        hCostText = transform.GetChild(1).GetChild(1).GetComponent<Text>();
        fCostText = transform.GetChild(1).GetChild(2).GetComponent<Text>();
        isWall = false;
        discovered = false;
    }

    public void SetID(int _id){id = _id;}
    public int GetID(){return id;}

    public void SetColor(Color col){
        ColorBlock colors = colorPanel.colors;
        colors.normalColor = col;
        colorPanel.colors = colors;
        EventSystem.current.SetSelectedGameObject(null);
    }

    public void CellClicked(){
        MapHandler.instance.CellClicked(id);
    }

    public void UpdateUI(){
        gCostText.text = GetComponent<CellNode>().GetGCost().ToString();
        hCostText.text = GetComponent<CellNode>().GetHCost().ToString();
        fCostText.text = GetComponent<CellNode>().GetFCost().ToString();
    }

    public void SetWall(bool _isWall){
        isWall = _isWall;
        if(isWall){
            SetColor(Style.wall_cell);
        }else{
            SetColor(Style.standard_cell);
        }
    }

    public bool IsWall(){
        return isWall;
    }

    public void SetDiscover(){
        discovered = true;
    }

    public bool IsDiscovered(){
        return discovered;
    }

}
