﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Style
{
    public static Color32 start_cell = new Color32(50,0,150,255);
    public static Color32 end_cell = new Color32(70,0,180,255);
    public static Color32 walked_cell = new Color32(0,215,0,255);
    public static Color32 far_cell = new Color32(215,0,0,255);
    public static Color32 current_cell = new Color32(215,215,0,255);
    public static Color32 final_path_cell = new Color32(215,0,215,255);
    public static Color32 wall_cell = new Color32(0,0,0,255);
    public static Color32 standard_cell = new Color32(255,255,255,255);
}
